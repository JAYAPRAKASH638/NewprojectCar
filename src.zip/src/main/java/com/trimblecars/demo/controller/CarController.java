package com.trimblecars.demo.controller;

import com.trimblecars.demo.models.Car;
import com.trimblecars.demo.service.CarService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cars")
@RequiredArgsConstructor
public class CarController {
    private final CarService carService;

    @PostMapping
    public ResponseEntity<Car> addCar(@RequestBody Car car) {
        return ResponseEntity.ok(carService.addCar(car));
    }

    @GetMapping
    public ResponseEntity<List<Car>> getCars() {
        return ResponseEntity.ok(carService.getAllCars());
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<Car> updateStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(carService.updateStatus(id, status));
    }
}