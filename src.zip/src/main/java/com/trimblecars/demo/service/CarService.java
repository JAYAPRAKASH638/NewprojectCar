package com.trimblecars.demo.service;

import com.trimblecars.demo.models.Car;
import com.trimblecars.demo.repository.CarRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public class CarService {
    private final CarRepository carRepo;

    public List<Car> getAllCars() {
        return carRepo.findAll();
    }

    public Car addCar(Car car) {
        car.setStatus("IDEAL");
        return carRepo.save(car);
    }

    public Car updateStatus(Long id, String status) {
        Car car = carRepo.findById(id).orElseThrow();
        car.setStatus(status);
        return carRepo.save(car);
    }
}
