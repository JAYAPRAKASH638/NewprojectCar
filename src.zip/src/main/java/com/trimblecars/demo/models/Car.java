package com.trimblecars.demo.models;
import com.trimblecars.demo.models.Car;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Setter
public class Car {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String model;
    private String status; // IDEAL, ON_LEASE, ON_SERVICE

    // If you have User mapping, include this:
    // @ManyToOne
    // private User owner;
}
