package com.trimblecars.demo.models;
import jakarta.persistence.*;
import lombok.*;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {

		// TODO Auto-generated method stub
		@Id
	    @GeneratedValue
	    private Long id;
	    private String name;
	    private String role; // OWNER, CUSTOMER, ADMIN}
	}

