package com.trimblecars.demo.models;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
public class Lease {
	@Id
    @GeneratedValue
    private Long id;

    @ManyToOne
    private User customer;

    @ManyToOne
    private Car car;

    private LocalDate startDate;
    private LocalDate endDate;
}
