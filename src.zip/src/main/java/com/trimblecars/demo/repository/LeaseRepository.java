package com.trimblecars.demo.repository;
import java.rmi.dgc.Lease;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LeaseRepository extends JpaRepository<Lease, Long> {}
