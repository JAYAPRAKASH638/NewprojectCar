package com.trimblecars.demo.repository;
import com.trimblecars.demo.models.Car;
import com.trimblecars.demo.repository.CarRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CarRepository extends JpaRepository<Car, Long> {
}